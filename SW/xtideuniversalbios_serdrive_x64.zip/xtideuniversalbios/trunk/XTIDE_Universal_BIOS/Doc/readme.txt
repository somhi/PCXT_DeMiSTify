See XTIDE Universal BIOS wiki pages for manual and other information:
http://code.google.com/p/xtideuniversalbios/w/list

XTIDE Universal BIOS discussion can be found at:
http://www.vintage-computer.com/vcforum/showthread.php?17986-XTIDE-Universal-BIOS
